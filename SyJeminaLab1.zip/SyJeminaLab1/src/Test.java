import com.company.lunchbox;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		lunchbox lb1 = new lunchbox();
		System.out.println("Lunchbox Dimensions");
		lb1.printDimensions(17.2, 23.0, 7.2, 1800);
		System.out.println();
		lb1.lunchBox("Green", "Lock n' Lock");
		System.out.println("Color of lunchbox is: " + lb1.getColor());
		System.out.println("Brand of lunchbox is: " + lb1.getBrand());
	}

}
